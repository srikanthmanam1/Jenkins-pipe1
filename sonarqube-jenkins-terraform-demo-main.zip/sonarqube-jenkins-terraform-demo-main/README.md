# Jenkins CICD Pipeline for Terraform Code
- AWS EC2 Instance launch
- Security Group to allow SSH port in Inbound
- SonarQube to do Static Code Analysis
- Jenkins Pipeline
- Terraform apply and destroy
